import {createRoot} from 'react-dom/client';
import CargoApp from './app/cargo-app';
import './app/globals.css';
createRoot(document.getElementById('root')!).render(<CargoApp/>);
